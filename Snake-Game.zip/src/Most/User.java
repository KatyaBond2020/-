package Most;
//Класс Игрок
public class User {
    private String name;
    private int score;
    private int level;
    //Конструктор с параметрами
    public User(String name, int score, int level) {
        this.name = name;
        this.score = score;
        this.level = level;
    }
    //Метод для получения имени
    public String getName(){
        return this.name;
    }
    //Метод для получения количества баллов
    public int getScore(){
        return this.score;
    }
    //Метод для получения уровня сложности
    public int getLevel(){
        return this.level;
    }
}
