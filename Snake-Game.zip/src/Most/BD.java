package Most;
import Most.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;

public class BD {
    private static Connection connection;
    //Подключение базы данных Game (из СУБД - SQL Server)
    public static void Connector(){
        String url = "jdbc:sqlserver://LAPTOP-QU5BK6SA;databaseName=Game";
        String username = "sa";
        String password = "123";
        try {
            connection = DriverManager.getConnection(url,username,password);
            System.out.println("Connect SQL");
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
    }
    private static final ObservableList<User> persons = FXCollections.observableArrayList();

    //Получение списка игроков
    public static ObservableList getPersons(){
        BD.Connector();
        read();
        return persons;
    }
    //Метод считывания из базы данных
    public static void read(){

        String sql = "SELECT*FROM TableRecords";
        persons.clear();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                String name = resultSet.getString("Name");
                int score = resultSet.getInt("Score");
                int level = resultSet.getInt("Level");
                persons.add(new User(name, score, level));
            }
        } catch (Exception throwable) {
            throwable.printStackTrace();
        }
    }
    //Добавление данных об игроке и результатах его игры в базу данных
    public static void addItem(User person){
        String sql = "insert TableRecords values('"+ person.getName() + "', "+person.getScore()+", " + person.getLevel() + ")";
        System.out.println(sql);
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }catch (NullPointerException throwable){
            throwable.printStackTrace();
        }
    }
    //Метод для выполнения сортировки. В параметры метода передается вид сортировки (по уровню или по баллам)
    public static void sort(String par){
        persons.clear();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM TableRecords ORDER BY "+ par);
           while (resultSet.next()){
                String name = resultSet.getString("Name");
                int score = resultSet.getInt("Score");
                int level= resultSet.getInt("Level");
                persons.add(new User(name, score, level));
            }
        } catch (Exception throwable) {
            throwable.printStackTrace();
        }
    }
}
