package rezult;
import Most.BD;
import Most.User;
import Play.ToPlay;
import Records.RecController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RezultController implements Initializable {
    @FXML
    private Button btnRec;
    @FXML
    private Button Exit;
    @FXML
    private Button SaveRez;
    @FXML
    private Label ScoreRez;
    @FXML
    private Label lablerez;
    @FXML
    private Label Mesto;
    @FXML
    private TextField NameText;
    ObservableList personsData = FXCollections.observableArrayList();
    //btnRec
    private int mesto(int score, int level){
    personsData = BD.getPersons();
    int s1=0;
    int s2=0;
    int s;
    for (var person : personsData) {
        if (((User) person).getLevel()==1){
            s1=s1+1;
        }else s2=s2+1;
    }
    if(level==1){
        for (var person : personsData) {
            if ((((User) person).getLevel()==1)&&(score>=((User) person).getScore())){
                s1=s1-1;
            }
        }
        s=s1;
    }else {
        for (var person : personsData) {
            if ((((User) person).getLevel()==2)&&(score>=((User) person).getScore())){
                s2=s2-1;
            }
        }
        s=s2;
    }
    return (s+1);
}
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ScoreRez.setText("Очков:"+String.valueOf(ToPlay.score));
        Mesto.setText("Место:"+mesto(ToPlay.score,ToPlay.idLevel));
        //Кнопка "Сохранить результат". Записывает данные о пользователе (Имя, количество баллов, уровень игры) базу данных
        SaveRez.setOnAction(event -> {

            String name = NameText.getText();
            int score = ToPlay.score;
            int level = ToPlay.idLevel;
            if (name!=""){
            BD.Connector();
            BD.addItem(new User(name, score, level));
            lablerez.setText("Результаты добавлены!");}
            else{
                lablerez.setText("Укажите ваше имя!");
            }
        });
        // Кнопка "Узнай результаты других". Переход в окно "Таблица рекордов"
        btnRec.setOnAction((event -> {
            BD.Connector();
            Stage stage = (Stage) btnRec.getScene().getWindow();
            stage.close();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/Records/TableRec.fxml"));
            RecController.BackId(2);
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Рекорды");
            stage.setResizable(false);
            stage.show();
        }));
        //Кнопка "Выход". Осуществляет выход из игрового приложения
        Exit.setOnAction((event -> {
            Runtime.getRuntime().exit(0);
        }));
        }
    }

