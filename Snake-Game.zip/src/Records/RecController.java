package Records;
import Most.BD;
import Most.User;
import Play.ToPlay;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
// Контроллер окна "Таблица рекордов"
public class RecController implements Initializable {
    private static String BackWindow;
    ObservableList personsData = FXCollections.observableArrayList();
    @FXML
    private TableView<User> TableRec;
    @FXML
    private TableColumn<User, String> ColNicName;
    @FXML
    private TableColumn<User, Integer> ColScore;
    @FXML
    private TableColumn<User, Integer> ColLevel;
    @FXML
    private ToggleGroup R;
    @FXML
    private RadioButton levelSort;
    @FXML
    private RadioButton ScoreSort;
    @FXML
    private Button Sort;
    @FXML
    private Button back;
    @FXML
    private Label LInfo;


    public static void BackId(int idBack){
        if (idBack==1){
            BackWindow = "/Menu/menu.fxml";
        } else BackWindow = "/rezult/Rezult.fxml";
    }
    @Override
    //Метод обработки нажатия кнопок и записи данных в таблицу
    public void initialize(URL url, ResourceBundle resourceBundle) {
        personsData = BD.getPersons();
        //заполнение таблицы на форме
                ColNicName.setCellValueFactory(new PropertyValueFactory<>("name"));
                ColScore.setCellValueFactory(new PropertyValueFactory<>("score"));
                ColLevel.setCellValueFactory(new PropertyValueFactory<>("level"));
                TableRec.setItems(personsData);
        //Кнапка "Сортировать". Осуществление сортировки данныхв зависимости от выбранного вида сортировки (по уровню сложности, по кол-ву баллов)
        Sort.setOnAction(event2 -> {
            if (this.R.getSelectedToggle()==null) {
                LInfo.setVisible(true);
            }else {
                LInfo.setVisible(false);
            if (this.R.getSelectedToggle().equals(this.levelSort)) {
                BD.sort("Level");//по уровню сложности
            }else
                BD.sort("Score");//по кол-ву баллам}
            }});
        // Кнопка "Назад". Осуществляет возврат к окну из которого было вызвано окно "Таблица рекордов"
        back.setOnAction((event -> {
            Stage stage = (Stage) back.getScene().getWindow();
            stage.close();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(BackWindow));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            stage = new Stage();
            stage.setScene(new Scene(root));
            if (BackWindow=="/rezult/Rezult.fxml"){
                stage.initStyle(StageStyle.UNDECORATED);
            }
            stage.setResizable(false);
            stage.show();
        }));
    }
}

