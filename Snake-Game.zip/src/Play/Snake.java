package Play;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
// Класс Змейка
public class Snake {
    public static List<Point> snakeBody= new ArrayList();
    private int ROWS;
    private int SQUARE_SIZE;
    Point snakeHead;
    //Конструктор с параметрами
    public Snake(int SQUARE_SIZE, int ROWS){
        this.SQUARE_SIZE = SQUARE_SIZE;
        this.ROWS = ROWS;
    }
    public static List<Point> getSnakeBody() {
        return snakeBody;
    }
    //Появление змейки при старте программы и установка начального местоположения
    public void startBody(){
        for (int i = 0; i < 3; i++) {
            snakeBody.add(new Point(5, ROWS / 2));
        }
        snakeHead = snakeBody.get(0);
    }
    //Прорисовка элементов змеи
    public void drawSnake(GraphicsContext gc) {
        gc.setFill(Color.web("#FF7700"));
        gc.fillRoundRect(snakeHead.getX() * SQUARE_SIZE, snakeHead.getY() * SQUARE_SIZE, SQUARE_SIZE-2 , SQUARE_SIZE - 2, 60, 70);
        for (int i = 1; i < snakeBody.size(); i++) {
            gc.fillRoundRect(snakeBody.get(i).getX() * SQUARE_SIZE, snakeBody.get(i).getY() * SQUARE_SIZE, SQUARE_SIZE - 5, SQUARE_SIZE - 5, 40, 70);
        }
        for (int i = snakeBody.size() - 1; i >= 1; i--) {
           snakeBody.get(i).x = snakeBody.get(i - 1).x;
            snakeBody.get(i).y = snakeBody.get(i - 1).y;
        }
    }
}
