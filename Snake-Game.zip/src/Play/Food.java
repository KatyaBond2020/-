package Play;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import java.awt.*;
// класс Еда
public class Food {
    private String[] FOODS_IMG = new String[]{
            "/img/orange.png", "/img/apple.png", "/img/banana.png", "/img/e.png"};
    private Image foodImage;
    int foodX;
    int foodY;
    private int ROWS;
    private int COLUMNS;
    private int SQUARE_SIZE;
    // Конструктор с параметрами
    public Food(int SQUARE_SIZE,int ROWS, int COLUMNS){
        this.ROWS = ROWS;
        this.COLUMNS = COLUMNS;
        this.SQUARE_SIZE = SQUARE_SIZE;
    }
    //Прорисовка еды
    public void drawFood(GraphicsContext gc) {
        gc.drawImage(foodImage, foodX * SQUARE_SIZE, foodY * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
    }
    //Метод для генерация еды в произвольной части экрана(обеспечивается с помощью мат. операции random)
    public void generateFood() {
        start:
        while (true) {
            foodX = (int) (Math.random() * ROWS);
            foodY = (int) (Math.random() * COLUMNS);
            for (Point snake : Snake.getSnakeBody())
                if ((snake.getX() == foodX) && (snake.getY() == foodY)) {
                    continue start;
                }
            foodImage = new javafx.scene.image.Image(FOODS_IMG[(int) (Math.random() * FOODS_IMG.length)]);
            break;
        }
    }
}
