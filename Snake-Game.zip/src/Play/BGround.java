package Play;
import javafx.scene.canvas.GraphicsContext;
// Класс игрового поля
public class BGround {
    private int ROWS;
    private int COLUMNS;
    private int SQUARE_SIZE;
    //Конструктор с параметрами
    public BGround(int SQUARE_SIZE,int ROWS,int COLUMNS){
        this.SQUARE_SIZE = SQUARE_SIZE;
        this.ROWS = ROWS;
        this.COLUMNS = COLUMNS;
    }
    //Прорисовка игрового пространства
    public void drawBackground(GraphicsContext gc) {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                gc.setFill(javafx.scene.paint.Color.GREEN);
                gc.fillRect(i * SQUARE_SIZE, j * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
            }
        }
    }
}
