package Play;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

import static java.lang.String.valueOf;

public class ToPlay {
    public static int score=0;
    public static int idLevel=0;
    private int WIDTH = 600;
    private int HEIGHT = WIDTH;
    private int ROWS = 20;
    private int COLUMNS = ROWS;
    private int SQUARE_SIZE = WIDTH / ROWS;
    private int number_moves =0;
    private static final int RIGHT = 0;
    private static final int LEFT = 1;
    private static final int UP = 2;
    private static final int DOWN = 3;
    private GraphicsContext gc;
    private boolean gameOver;
    private int oper;
    Snake snake;
    Food food;
    Timeline timeline;
    //Запуск игрового окна. Установка уровня сожности
    public void start(int id) {
        Stage primaryStage = new Stage();
        Group root = new Group();
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        root.getChildren().add(canvas);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.initStyle(StageStyle.UNDECORATED);
        primaryStage.show();
        gc = canvas.getGraphicsContext2D();
        scene.setOnKeyPressed(new EventHandler<KeyEvent>() { //обработчик нажатия кнопок
            @Override
            public void handle(KeyEvent event) {

                KeyCode code = event.getCode();
                if (code == KeyCode.RIGHT) {
                    if (oper != LEFT) {
                        oper = RIGHT;
                    }
                    number_moves=number_moves+1;
                } else if (code == KeyCode.LEFT) {
                    if (oper != RIGHT) {
                        oper = LEFT;
                    }
                    number_moves=number_moves+1;
                } else if (code == KeyCode.UP) {
                    if (oper != DOWN) {
                        oper = UP;
                    }
                    number_moves=number_moves+1;
                } else if (code == KeyCode.DOWN) {
                    if (oper != UP) {
                        oper = DOWN;
                    }
                    number_moves=number_moves+1;
                }
            }
        });
        snake = new  Snake(SQUARE_SIZE,ROWS);
        food = new Food(SQUARE_SIZE,ROWS,COLUMNS);
        snake.startBody();
        food.generateFood();
        int speed = 0;
        switch (id){
            case 1: {
                idLevel=1;
                speed = 300;
                break;
            }
            case 2:{
                idLevel=2;
                speed = 150;
                break;
            }
        }
        timeline = new Timeline((new KeyFrame(Duration.millis(speed), e -> run(gc))));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }
    //Старт игры
    private void run(GraphicsContext gc) {
        // при проигрыше открывается окно "Pfdthitybz buhs"
        if (gameOver) {
            timeline.stop();
            Stage primaryStage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/rezult/Rezult.fxml"));
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            primaryStage.setScene(new Scene(root, 370, 370));
            primaryStage.initStyle(StageStyle.UNDECORATED);
            primaryStage.show();
        }
        BGround b = new BGround(SQUARE_SIZE,ROWS,COLUMNS);
        b.drawBackground(gc);
        food.drawFood(gc);
        snake.drawSnake(gc);
        switch (oper) {
            case RIGHT:{
                moveRight();
                break;}
            case LEFT:{
                moveLeft();
                break;}
            case UP:{
                moveUp();
                break;}
            case DOWN:{
                moveDown();
                break;}
        }
        drawScore();
        drawNumber_moves();
        eatFood();
        gameOver();
    }
    //Поворот головы змеи вправо
    private void moveRight() {
        snake.snakeHead.x++;
        number_moves=number_moves++;
    }
    //Поворот головы змеи влево
    private void moveLeft() {
        snake.snakeHead.x--;
        number_moves=number_moves++;
    }
    //Поворот головы змеи вверх
    private void moveUp() {
        snake.snakeHead.y--;
        number_moves=number_moves++;
    }
    //Поворот головы змеи вниз
    private void moveDown() {
        snake.snakeHead.y++;
        number_moves=number_moves++;
    }
    //Метод для проверки врезалась ли змейка или нет (проверяется вышла ли голова змейки за пределы игрового поля; равны ли координаты головы координатам сегментов тела змейки)
    private void gameOver() {
        if (snake.snakeHead.x < 0 || snake.snakeHead.y < 0 || snake.snakeHead.x * SQUARE_SIZE >= WIDTH || snake.snakeHead.y * SQUARE_SIZE >= HEIGHT) {
            gameOver = true;
        }
        for (int i = 1; i < snake.snakeBody.size(); i++) {
            if (snake.snakeHead.x == snake.snakeBody.get(i).getX() && snake.snakeHead.getY() == snake.snakeBody.get(i).getY()) {
                gameOver = true;
                break;
            }
        }
    }
    //Подсчет очков. Максимальное количество баллов если совершено от 0 до 2 ходов (минимальное возможное число ходов для достижения фрукта из любого положения змейки). Если до достижения фрукта сделано более двух ходов, то за каждый штрафной ход от максимального количества отнимается по одному баллу.
    private void eatFood() {
        if (snake.snakeHead.getX() == food.foodX && snake.snakeHead.getY() == food.foodY) {
            snake.snakeBody.add(new Point(-1, -1));
            if ((number_moves>=0)&&(number_moves<=2)){
                score += 5;
            }else{
                int n=0;
                if ((number_moves > 2) && (number_moves < 7)) {
                    for(int i=3; i<=number_moves;i++){
                        n++;
                    }
                        score+=5-n;
                }else score+=0;
            }
            food.generateFood();
            number_moves=0;
        }
    }
    //вывод очков на экран
    private void drawScore() {
        gc.setFill(Color.WHITE);
        gc.setFont(new Font("Digital-7", 25));
        gc.fillText("Очки:" + score, 10, 35);
    }
    //вывод количество сделанных ходов на экран
    private void drawNumber_moves() {
        gc.setFill(Color.WHITE);
        gc.setFont(new Font("Digital-7", 25));
        gc.fillText("Кол-во ходов:" + number_moves, 390, 35);
    }
}
