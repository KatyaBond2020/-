package Menu;
import Most.BD;
import Play.ToPlay;
import Records.RecController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
//Контроллер для окна "Меню" реализует кнопки выбора уровня игры, начало игры, перехода к таблице рекордов
public class MenuController implements Initializable {
    @FXML
    private Button btnLevel;
    @FXML
    private Button btnStart;
    @FXML
    private Button btnRec;
    @FXML
    private ToggleGroup R1;
    @FXML
    private RadioButton easy;
    @FXML
    private RadioButton difficult;
    ToPlay game;

    //метод для появления скрытых Radiobutton, отвечающих за выбор уровня сложности игры, при нажатии на кнопку "Уровень сложности"
    public void Levels(javafx.event.ActionEvent event) {
        easy.setVisible(true);
        difficult.setVisible(true);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Кнопка "Начать игру". Запуск игры
        btnStart.setOnAction(event -> {

            game = new ToPlay();
            if (this.R1.getSelectedToggle().equals(this.easy)) {
                game.start(1);
            }else game.start(2);
            event.consume();
            Stage stage = (Stage) btnStart.getScene().getWindow();
            stage.close();
        });
        //Кнопка "рекорды". Переход в окно "Таблица рекордов"
        btnRec.setOnAction((event -> {
            BD.Connector();
            Stage stage = (Stage) btnRec.getScene().getWindow();
            stage.close();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/Records/TableRec.fxml"));
            RecController.BackId(1);
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Рекорды");
            stage.setResizable(false);
            stage.show();
        }));
    }
}
